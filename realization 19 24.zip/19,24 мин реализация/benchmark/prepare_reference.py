"""Minimal reproducible data/reference builder for issues #19 and #24.

Input is a normalized network-events CSV. This keeps the LANL-specific parsing
separate from the common benchmark pipeline.

Required columns:
    timestamp, src, dst
Optional columns:
    bytes, packets, dst_port, proto

The script:
1. filters one documented time window;
2. keeps stable host_id = original host string;
3. aggregates events into a host graph edge list;
4. builds independent reference features;
5. creates canonical pairs/triplets from that reference space;
6. copies an explicitly supplied host target file to labels.csv.

Pairs/triplets are created once and are never derived from evaluated embeddings.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

REQUIRED = ["timestamp", "src", "dst"]

def load_events(path: Path, start: str | None, end: str | None) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"missing required columns: {missing}")
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="raise")
    for c, default in [("bytes", 0.0), ("packets", 1.0), ("dst_port", 0), ("proto", "unknown")]:
        if c not in df:
            df[c] = default
    df["src"] = df["src"].astype(str)
    df["dst"] = df["dst"].astype(str)
    if start:
        df = df[df["timestamp"] >= pd.Timestamp(start, tz="UTC")]
    if end:
        df = df[df["timestamp"] < pd.Timestamp(end, tz="UTC")]
    if df.empty:
        raise ValueError("time window contains no events")
    return df.sort_values(["timestamp", "src", "dst"]).reset_index(drop=True)

def build_graph(events: pd.DataFrame) -> pd.DataFrame:
    # One undirected edge per host pair, with deterministic aggregate counts.
    a = events[["src","dst","bytes","packets"]].copy()
    a["host_a"] = np.minimum(a["src"], a["dst"])
    a["host_b"] = np.maximum(a["src"], a["dst"])
    edges = (a.groupby(["host_a","host_b"], as_index=False)
             .agg(events=("src","size"), bytes=("bytes","sum"), packets=("packets","sum")))
    return edges[edges.host_a != edges.host_b].sort_values(["host_a","host_b"])

def build_reference_features(events: pd.DataFrame) -> pd.DataFrame:
    hosts = pd.Index(sorted(set(events.src) | set(events.dst)), name="host_id")
    out = events.groupby("src").agg(out_events=("dst","size"), out_bytes=("bytes","sum"),
                                    out_peers=("dst","nunique"))
    inc = events.groupby("dst").agg(in_events=("src","size"), in_bytes=("bytes","sum"),
                                    in_peers=("src","nunique"))
    x = out.join(inc, how="outer").reindex(hosts).fillna(0.0)
    x["out_in_event_ratio"] = x.out_events / (x.out_events + x.in_events).replace(0, 1)
    x["out_in_byte_ratio"] = x.out_bytes / (x.out_bytes + x.in_bytes).replace(0, 1)
    # A small independent behavioral feature space: volume, direction and degree.
    cols = ["out_events","in_events","out_bytes","in_bytes","out_peers","in_peers",
            "out_in_event_ratio","out_in_byte_ratio"]
    x[cols[:6]] = np.log1p(x[cols[:6]])
    z = (x[cols] - x[cols].mean()) / x[cols].std(ddof=0).replace(0, 1)
    z = z.replace([np.inf,-np.inf],0).fillna(0)
    z.columns = [f"ref_{i}" for i in range(z.shape[1])]
    z.insert(0, "host_id", hosts.astype(str))
    return z

def canonical_pairs(features: pd.DataFrame, positive_k: int = 3, negatives_per_host: int = 3, seed: int = 42):
    ids = features.host_id.tolist()
    X = features.filter(regex=r"^ref_").to_numpy(float)
    sim = cosine_similarity(X)
    rng = np.random.default_rng(seed)
    rows=[]
    for i, h in enumerate(ids):
        order = np.argsort(-sim[i], kind="stable")
        pos=[j for j in order if j != i][:min(positive_k, len(ids)-1)]
        neg_candidates=[j for j in range(len(ids)) if j != i and j not in set(pos)]
        neg= rng.choice(neg_candidates, size=min(negatives_per_host,len(neg_candidates)), replace=False) if neg_candidates else []
        for j in pos: rows.append((h, ids[j], 1, "test"))
        for j in neg: rows.append((h, ids[int(j)], 0, "test"))
    return pd.DataFrame(rows, columns=["host_a","host_b","label","split"]).drop_duplicates()

def canonical_triplets(pairs: pd.DataFrame, features: pd.DataFrame):
    ids=features.host_id.tolist()
    X=features.filter(regex=r"^ref_").to_numpy(float)
    sim=cosine_similarity(X)
    pos_map={}
    neg_map={}
    for r in pairs.itertuples(index=False):
        if r.label==1: pos_map.setdefault(r.host_a,[]).append(r.host_b)
        else: neg_map.setdefault(r.host_a,[]).append(r.host_b)
    rows=[]
    for a in ids:
        for p,n in zip(pos_map.get(a,[]), neg_map.get(a,[])):
            rows.append((a,p,n,"test"))
    return pd.DataFrame(rows, columns=["anchor","positive","negative","split"])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--events", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--start")
    ap.add_argument("--end")
    ap.add_argument("--labels", type=Path, help="CSV with host_id,target")
    ap.add_argument("--seed", type=int, default=42)
    args=ap.parse_args()
    out=args.output_dir
    (out/"reference").mkdir(parents=True, exist_ok=True)
    (out/"graph").mkdir(parents=True, exist_ok=True)
    events=load_events(args.events,args.start,args.end)
    graph=build_graph(events)
    features=build_reference_features(events)
    pairs=canonical_pairs(features,seed=args.seed)
    triplets=canonical_triplets(pairs,features)
    if args.labels:
        labels=pd.read_csv(args.labels)
        if not {"host_id","target"} <= set(labels.columns):
            raise ValueError("labels must contain host_id,target")
        labels=labels[["host_id","target"]].copy()
    else:
        # Demo-only target: deterministic coarse activity class.
        # Real experiments must replace this with a documented target source.
        activity=features.set_index("host_id")["ref_0"]
        median=float(activity.median())
        labels=pd.DataFrame({"host_id":features.host_id,
                             "target":np.where(activity.reindex(features.host_id).to_numpy()>=median,"high_activity","low_activity")})
    labels["split"]="test"
    features.to_csv(out/"reference/features.csv",index=False)
    pairs.to_csv(out/"reference/pairs.csv",index=False)
    triplets.to_csv(out/"reference/triplets.csv",index=False)
    labels.to_csv(out/"reference/labels.csv",index=False)
    graph.to_csv(out/"graph/edges.csv",index=False)
    events.to_csv(out/"processed_events.csv",index=False)
    manifest={
      "input":"normalized network events",
      "start":args.start,"end":args.end,"seed":args.seed,
      "host_id_rule":"host_id is the original normalized host identifier string",
      "graph_rule":"one undirected edge per unordered host pair; events/bytes/packets are aggregated",
      "reference_features_rule":"independent host behavior features: volume, direction and peer counts",
      "pairs_rule":"positive = top reference-space cosine neighbors; negative = fixed-seed sampled non-positive hosts",
      "triplets_rule":"anchor-positive from positive pairs, anchor-negative from negative pairs",
      "labels_rule":"supplied host_id,target if --labels is used; otherwise demo-only median activity target",
      "split_rule":"all generated rows are marked test for the minimal example; production experiments must define train/validation/test temporal windows before evaluation"
    }
    (out/"manifest.json").write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(f"prepared {len(features)} hosts, {len(graph)} graph edges, {len(pairs)} pairs, {len(triplets)} triplets")

if __name__=="__main__": main()
