# Минимальная реализация Issue #19 + #24

## Что здесь реализовано

1. `benchmark/prepare_reference.py`
   - принимает нормализованные сетевые события;
   - фиксирует временное окно;
   - сохраняет стабильный `host_id`;
   - строит `graph/edges.csv`;
   - создаёт единые `reference/features.csv`, `pairs.csv`, `triplets.csv`, `labels.csv`;
   - записывает `manifest.json` с правилами построения.

2. `evaluation/retrieval_metrics.py`
   - использует **только общий** `pairs.csv`;
   - считает Precision@k и Recall@k;
   - использует одинаковые значения k для всех embedding-методов;
   - не создаёт собственную разметку.

3. `evaluation/evaluate_retrieval.py`
   - общий CLI для embeddings + canonical pairs.

## Быстрый запуск

```bash
python -m venv .venv
pip install pandas numpy scikit-learn
python benchmark/prepare_reference.py \
    --events examples/raw_events.csv \
    --output-dir examples/processed \
    --labels examples/host_labels.csv
```

После этого появятся:

```text
examples/processed/
├── processed_events.csv
├── manifest.json
├── graph/edges.csv
└── reference/
    ├── features.csv
    ├── pairs.csv
    ├── triplets.csv
    └── labels.csv
```

Для #24:

```bash
python -m evaluation.evaluate_retrieval \
  --embeddings examples/embeddings.csv \
  --pairs examples/processed/reference/pairs.csv
```

## Важное ограничение

Это именно минимальный общий конвейер, а не готовый адаптер к конкретному сырому формату LANL.

Сырой LANL формат сначала должен быть приведён к нормализованным полям:

```text
timestamp, src, dst
```

с необязательными:

```text
bytes, packets, dst_port, proto
```

Так мы не выдумываем структуру исходного датасета, которой в ТЗ не зафиксировано.

В демонстрационном режиме `labels.csv` можно получить автоматически, но для реального эксперимента target должен быть передан отдельным документированным источником через `--labels`.

## Что соответствует критериям готовности

- воспроизводимый запуск: да;
- стабильный `host_id`: да;
- временное окно: задаётся явно и сохраняется в `manifest.json`;
- правило построения графа: зафиксировано;
- небольшой пример: есть;
- единые reference-файлы: создаются один раз;
- reference не зависит от оцениваемого embedding: да;
- P@k/R@k используют общий `pairs.csv`: да;
- k берётся явно из запуска; в репозитории должен оставаться `benchmark/config.json` с `[5,10,20]`.
