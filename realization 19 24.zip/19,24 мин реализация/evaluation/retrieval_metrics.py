"""Precision@k / Recall@k using canonical reference/pairs.csv."""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

def load_relevance(pairs_path, split="test"):
    pairs=pd.read_csv(pairs_path)
    required={"host_a","host_b","label","split"}
    if not required <= set(pairs.columns):
        raise ValueError(f"pairs file must contain {sorted(required)}")
    pairs=pairs[pairs["split"]==split]
    rel={}
    for r in pairs.itertuples(index=False):
        a,b=str(r.host_a),str(r.host_b)
        if int(r.label)==1:
            rel.setdefault(a,set()).add(b)
            rel.setdefault(b,set()).add(a)
    return rel

def precision_recall_at_k(embeddings: pd.DataFrame, relevance: dict[str,set[str]], ks=(5,10,20)):
    if embeddings.index.has_duplicates:
        raise ValueError("duplicate host_id values in embeddings")
    ids=[str(x) for x in embeddings.index]
    X=embeddings.to_numpy(float)
    if not np.isfinite(X).all():
        raise ValueError("embeddings contain NaN/Inf")
    sim=cosine_similarity(X)
    rows=[]
    for k in ks:
        if k <= 0: raise ValueError("k must be positive")
        effective=min(k,max(0,len(ids)-1))
        for i,a in enumerate(ids):
            order=np.argsort(-sim[i],kind="stable")
            top=[ids[j] for j in order if j!=i][:effective]
            rel=relevance.get(a,set())
            hits=sum(x in rel for x in top)
            precision=hits/effective if effective else float("nan")
            recall=hits/len(rel) if rel else float("nan")
            rows.append({"host_id":a,"k":k,"precision":precision,"recall":recall,"n_relevant":len(rel)})
    return pd.DataFrame(rows)

def summarize(metrics: pd.DataFrame):
    return metrics.groupby("k")[["precision","recall"]].mean().rename(
        columns={"precision":"precision_at_k","recall":"recall_at_k"}
    )
