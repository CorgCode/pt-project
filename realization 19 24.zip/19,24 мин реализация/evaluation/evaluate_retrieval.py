"""Minimal common evaluator for issue #24 retrieval metrics."""
from __future__ import annotations
import argparse, json
from pathlib import Path
import pandas as pd
from evaluation.retrieval_metrics import load_relevance, precision_recall_at_k, summarize

def load_embeddings(path: Path):
    df=pd.read_csv(path)
    if "host_id" not in df:
        raise ValueError("embeddings.csv must contain host_id")
    cols=[c for c in df if c.startswith("emb_")]
    if not cols: raise ValueError("no emb_* columns")
    if df.host_id.duplicated().any(): raise ValueError("duplicate host_id")
    if df[cols].isna().any().any(): raise ValueError("NaN in embeddings")
    return df.set_index("host_id")[cols]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--embeddings",type=Path,required=True)
    ap.add_argument("--pairs",type=Path,required=True)
    ap.add_argument("--k",type=int,nargs="+",default=None)
    ap.add_argument("--config",type=Path,default=Path("benchmark/config.json"))
    ap.add_argument("--split",default="test")
    ap.add_argument("--output",type=Path)
    args=ap.parse_args()
    emb=load_embeddings(args.embeddings)
    rel=load_relevance(args.pairs,args.split)
    k_values = args.k
    if k_values is None:
        if args.config.exists():
            k_values = json.loads(args.config.read_text(encoding="utf-8")).get("k_values", [5,10,20])
        else:
            k_values = [5,10,20]
    missing=set(rel)-set(map(str,emb.index))
    if missing:
        raise ValueError(f"reference contains hosts absent from embeddings, e.g. {sorted(missing)[:5]}")
    per_host=precision_recall_at_k(emb,rel,k_values)
    summary=summarize(per_host)
    result={"n_hosts":len(emb),"split":args.split,"k_values":k_values,
            "metrics":{str(k):summary.loc[k].dropna().to_dict() for k in summary.index}}
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2))
if __name__=="__main__": main()
