import pandas as pd
import numpy as np
from evaluation.retrieval_metrics import precision_recall_at_k

def test_perfect_embedding():
    emb=pd.DataFrame({"emb_0":[1,1,-1,-1],"emb_1":[0.01,-0.01,0.01,-0.01]},
                     index=["a","b","c","d"])
    rel={"a":{"b"},"b":{"a"},"c":{"d"},"d":{"c"}}
    out=precision_recall_at_k(emb,rel,ks=(1,))
    assert out.groupby("k").precision.mean().iloc[0] == 1.0
    assert out.groupby("k").recall.mean().iloc[0] == 1.0

def test_no_relevant_is_nan_recall():
    emb=pd.DataFrame(np.eye(3),index=["a","b","c"])
    out=precision_recall_at_k(emb,{"a":{"b"}},ks=(1,))
    assert pd.isna(out[out.host_id=="c"].recall).all()
